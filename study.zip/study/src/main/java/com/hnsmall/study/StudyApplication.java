package com.hnsmall.study;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudyApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudyApplication.class, args);
	}

}



/*


ultrasrtncstultrasrtncstshow databases;

USE study;

CREATE TABLE UltraSrtNcst(    
  resultCode VARCHAR(50), 
  resultMsg VARCHAR(5000),
  numOfRows VARCHAR(50), 
  pageNo VARCHAR(50),
  totalCount VARCHAR(50) ,                      
  dataType VARCHAR(50) ,                      
  baseDate VARCHAR(50) ,     
  baseTime VARCHAR(50) ,   
  nx VARCHAR(50) ,   
  ny VARCHAR(50) ,   
  category VARCHAR(50) ,   
  obsrValue VARCHAR(50) 
);
commit;
insert into UltraSrtNcst  (resultCode, resultMsg, numOfRows, pageNo, totalCount, dataType, baseDate,baseTime,nx ,ny ,category ,obsrValue) values 
 ('resultCode_sample', 'resultMsg_sample', 'numOfRows_sample', 'pageNo_sample', 'totalCount_sample', 'dataType_sample', 'baseDate_sample','baseTime_sample','nx_sample' ,'ny_sample' ,'category_sample' ,'obsrValue_sample');
 commit;
 
 select * from UltraSrtNcst;
 

*/